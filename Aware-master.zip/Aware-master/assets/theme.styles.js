export default {
    primary: '#F6F6EE',
    secondary: '#F16653',
    tertiary: '#E3E0CD',
}