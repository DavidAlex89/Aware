import React from 'react'
import { StyleSheet, Text, View } from 'react-native'

const TranslatorScreen = () => {
    return (
        <View>
            <Text></Text>
        </View>
    )
}

export default TranslatorScreen

const styles = StyleSheet.create({})
